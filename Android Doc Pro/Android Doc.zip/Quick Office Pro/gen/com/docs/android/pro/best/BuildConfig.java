/** Automatically generated file. DO NOT MODIFY */
package com.docs.android.pro.best;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}