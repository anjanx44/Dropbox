package com.shiam.mypractice;

import java.util.Locale;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Myactivity extends Activity implements TextToSpeech.OnInitListener{

	EditText input;
	Button command;
	TextToSpeech tts;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_myactivity);
		input = (EditText) findViewById(R.id.etTakeInput);
		command = (Button) findViewById(R.id.bStartDialog);
		tts = new TextToSpeech(this, this);
		command.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				speak();
			}
		});
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		 if (tts != null) {
	            tts.stop();
	            tts.shutdown();
		 }
	}

	@Override
	public void onInit(int status) {
		// TODO Auto-generated method stub
		if (status == TextToSpeech.SUCCESS) {
			 
            int result = tts.setLanguage(Locale.US);
 
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "This Language is not supported");
            } else {
                speak();
            }
 
        } else {
            Log.e("TTS", "Initilization Failed!");
        }
	}
	public void speak(){
		String text = input.getText().toString();
		tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
	}

}