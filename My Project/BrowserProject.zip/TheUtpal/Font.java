package com.androidqa;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class Font extends TextView {
	 
	public Font(Context context) {
		super(context);
		 
		init();
		// TODO Auto-generated constructor stub
	}
	
	public Font(Context context, AttributeSet attrs) {
		super(context, attrs);
		 
		init();
		// TODO Auto-generated constructor stub
	}
	
	 public Typeface init()
	    {
	    	Typeface tf=Typeface.createFromAsset(getContext().getAssets(),"HanzelNormal.ttf");
	    	setTypeface(tf);
	    	return tf;
	    }
	 public Typeface init1()
	    {
	    	Typeface tf=Typeface.createFromAsset(getContext().getAssets(),"arialbd.ttf");
	    	setTypeface(tf);
	    	return tf;
	    }
	

}
