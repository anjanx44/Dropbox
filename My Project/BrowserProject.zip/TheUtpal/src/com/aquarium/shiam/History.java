package com.aquarium.shiam;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class History extends ListActivity implements OnItemClickListener,OnClickListener,OnItemLongClickListener {
	ListView mainListView;
//	ArrayList<String> planetList;
//	ArrayAdapter<String> listAdapter;
	String[] site_URL = new String[] { "NO DATA" };
	String[] site_row_id = new String[] { "" };
	long current_row_id;
	Dialog dialog;
	String Url;
	TextView showURL;
	Button deleteButten,cancelButton;
	SampleBrowser myaddress = new SampleBrowser();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listview);
		myaddress.setReturnCheck(true);
		SetInfo();
	
		ReadyDialog();
		showURL = (TextView) dialog.findViewById(R.id.tvsetHistory);
		deleteButten = (Button) dialog.findViewById(R.id.bDeleteHistory);
		cancelButton = (Button) dialog.findViewById(R.id.bCancel);
		deleteButten.setOnClickListener(this);
		cancelButton.setOnClickListener(this);
		mainListView.setOnItemClickListener(this);
		mainListView.setOnItemLongClickListener(this);
	}
	private void SetInfo() {
		
		ArrayList<HashMap<String, String>> planetList = new ArrayList<HashMap<String, String>>();
		
		Merit info = new Merit(this);
		info.open();
		String returned = info.getHistoryData();
		if (returned.equals(",")){
			site_URL = new String[]{ "NO DATA" };
			site_row_id = new String[]{ "" };
		}else {
			String[] myArr = returned.split(",");
			site_URL = myArr[0].split(" ");
			site_row_id = myArr[1].split(" ");
		}
		info.close();
		for (int i = 0; i < site_URL.length; i++) {
			// creating new HashMap
			HashMap<String, String> map = new HashMap<String, String>();
			// adding each child node to HashMap key => value
			map.put("Site_URL", site_URL[i]);

			// adding HashList to ArrayList
			planetList.add(map);
		}
		ListAdapter adapter = new SimpleAdapter(this, planetList,
				R.layout.simplehistoryrow,
				new String[] { "Site_URL" }, new int[] {
						R.id.tvGetSiteHistoryURL });
		setListAdapter(adapter);
		mainListView = getListView();
	}	
	public void ReadyDialog() {
		// set up dialog
		dialog = new Dialog(History.this);
		dialog.setContentView(R.layout.myhistorydialog);
		dialog.setTitle("Edit Bookmark");
		dialog.setCancelable(true);
		dialog.getWindow().setLayout(400, 400);
	}	
	@Override
	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub
		if(site_URL[arg2].equals("NO DATA")){
			Toast.makeText(getApplicationContext(), "Sorry, No data in History" , Toast.LENGTH_SHORT).show();
			return true;
		}
		current_row_id = Integer.parseInt(site_row_id[arg2]);
		showURL.setText(site_URL[arg2]);
		dialog.show();
		return true;
	}
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if(site_URL[arg2].equals("NO DATA")){
			Toast.makeText(getApplicationContext(), "Sorry, No data in History" , Toast.LENGTH_SHORT).show();
			return;
		}
//		Toast.makeText(this,"Name : "+ site_URL[arg2] + "\nAddress : " + site_URL[arg2] +"\nRow ID : " + site_row_id[arg2], Toast.LENGTH_SHORT)
//		.show();
		Intent myin = new Intent(getApplicationContext(),SampleBrowser.class);
		myin.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		SampleBrowser myaddress = new SampleBrowser();
		myaddress.setURLFrom(site_URL[arg2]);
		myaddress.setReturnCheck(false);
		startActivity(myin);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bDeleteHistory:
			dialog.dismiss();
			showAlert();			
			break;			
		case R.id.bCancel:
			dialog.dismiss();
			break;
		}
	}
	public void doDelete(){		
		boolean diditWork = true;
		try {
			long lRow1 = current_row_id;
			Merit ex1 = new Merit(this);
			ex1.open();
			ex1.deleteHistoryEntry(lRow1);
			ex1.close();
		} catch (Exception e) {
			diditWork = false;
			String error = e.toString();
			Dialog d = new Dialog(this);
			d.setTitle("Dang it ! ");
			TextView tv = new TextView(this);
			tv.setTextColor(Color.WHITE);
			tv.setText(error);
			d.setContentView(tv);
			d.show();
			}finally {
				if (diditWork) {
					Toast.makeText(getApplicationContext(), "Yeah it's done !", Toast.LENGTH_SHORT).show();
				}
			}
			SetInfo();
			//d.dismiss();
	}
	public void showAlert(){
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(History.this);
        alertDialog.setTitle("Confirm Delete...");
        alertDialog.setMessage("Are you sure you want delete this?");
		
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
 
            // Write your code here to invoke YES event
            //Toast.makeText(getApplicationContext(), "You clicked on YES", Toast.LENGTH_SHORT).show();
            doDelete();
            }
        });
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            // Write your code here to invoke NO event
            //Toast.makeText(getApplicationContext(), "You clicked on NO", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
            }
        });
        alertDialog.show();
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.history_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.mAddNew:
			DeleteAllshowAlert();
			break;
		case R.id.mExitBookmark:
			finish();
			break;
		}
		return false;
	}	
	public void DeleteAllshowAlert(){
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(History.this);
        alertDialog.setTitle("Confirm Delete...");
        alertDialog.setMessage("Are you sure you want delete all history?");
		
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
        	Merit ex1 = new Merit(History.this);
			ex1.open();
			ex1.DeleteAllHistory();
			ex1.close();
			SetInfo();
            }
        });
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            }
        });
        alertDialog.show();
	}
}
