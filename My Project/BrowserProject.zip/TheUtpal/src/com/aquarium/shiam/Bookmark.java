package com.aquarium.shiam;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;

public class Bookmark extends ListActivity implements OnClickListener,
		OnItemClickListener, OnItemLongClickListener {

	ListView mainListView;
	// ArrayList<String> planetList;
	// ArrayAdapter<String> listAdapter;
	String[] site_names = new String[] { "NO DATA" };
	String[] site_URL = new String[] { "" };
	String[] site_row_id = new String[] { "" };
	long current_row_id;
	EditText name, url, NewName, NewUrl;
	Dialog dialog, addnewDialog;
	Button buttonCancel, buttonOk, buttonDelete, buttonAddnew, buttonAddCancel;
	String Name, Url;
	boolean diditWork;
	SampleBrowser myaddress = new SampleBrowser();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listview);
		myaddress.setReturnCheck(true);
		SetInfo();

		mainListView.setOnItemClickListener(this);
		mainListView.setOnItemLongClickListener(this);	
		
		ReadyDialog();
		AddNewBookmark();
		name = (EditText) dialog.findViewById(R.id.etName);
		url = (EditText) dialog.findViewById(R.id.etURL);
		NewName = (EditText) addnewDialog.findViewById(R.id.etgetNewName);
		NewUrl = (EditText) addnewDialog.findViewById(R.id.etgetNewURL);
		buttonOk = (Button) dialog.findViewById(R.id.bOK);
		buttonCancel = (Button) dialog.findViewById(R.id.bCancel);
		buttonDelete = (Button) dialog.findViewById(R.id.bDeleteBookMark);
		buttonAddnew = (Button) addnewDialog
				.findViewById(R.id.bOkAddNewBookmark);
		buttonAddCancel = (Button) addnewDialog
				.findViewById(R.id.bCancelAddingBookmark);
		buttonAddnew.setOnClickListener(this);
		buttonCancel.setOnClickListener(this);
		buttonDelete.setOnClickListener(this);
		buttonOk.setOnClickListener(this);
		buttonAddCancel.setOnClickListener(this);
	}
	private void SetInfo() {

		ArrayList<HashMap<String, String>> planetList = new ArrayList<HashMap<String, String>>();

		Merit info = new Merit(this);
		info.open();
		String returned = info.getData();
		if (returned.equals(",,")) {
			site_names = new String[] { "NO DATA" };
			site_URL = new String[] { "NO DATA" };
			site_row_id = new String[] { "" };
		} else {
			String[] myArr = returned.split(",");
			site_names = myArr[0].split(" ");
			site_URL = myArr[1].split(" ");
			site_row_id = myArr[2].split(" ");
		}
		info.close();
		for (int i = 0; i < site_names.length; i++) {
			// creating new HashMap
			HashMap<String, String> map = new HashMap<String, String>();
			// adding each child node to HashMap key => value
			map.put("Site_Name", site_names[i]);
			map.put("Site_URL", site_URL[i]);

			// adding HashList to ArrayList
			planetList.add(map);
		}
		ListAdapter adapter = new SimpleAdapter(this, planetList,
				R.layout.simplerow,
				new String[] { "Site_Name", "Site_URL" }, new int[] {
						R.id.tvGetSiteName, R.id.tvGetSiteURL });
		setListAdapter(adapter);
		mainListView = getListView();
	}
	public void ReadyDialog() {
		// set up dialog
		dialog = new Dialog(Bookmark.this);
		dialog.setContentView(R.layout.mydialog);
		dialog.setTitle("Edit Bookmark");
		dialog.setCancelable(true);
		dialog.getWindow().setLayout(400, 500);
	}
	public void AddNewBookmark() {
		// set up dialog
		addnewDialog = new Dialog(Bookmark.this);
		addnewDialog.setContentView(R.layout.mydialog_add_item);
		addnewDialog.setTitle("Enter Bookmark");
		addnewDialog.setCancelable(true);
		addnewDialog.getWindow().setLayout(400, 500);
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
	@Override
	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub
		if (site_names[arg2].equals("NO DATA")) {
			Toast.makeText(getApplicationContext(),
					"Sorry, No data in Bookmark \n" + "Please insert One ",
					Toast.LENGTH_SHORT).show();
			return true;
		}
		current_row_id = Long.parseLong(site_row_id[arg2]);
		name.setText(site_names[arg2]);
		url.setText(site_URL[arg2]);
		dialog.show();
		return true;
	}
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if (site_names[arg2].equals("NO DATA")) {
			Toast.makeText(getApplicationContext(),
					"Sorry, No data in Bookmark \n" + "Please insert One ",
					Toast.LENGTH_SHORT).show();
			return;
		}
//		Toast.makeText(
//				this,
//				"Name : " + site_names[arg2] + "\nAddress : " + site_URL[arg2]
//						+ "\nRow ID : " + site_row_id[arg2], Toast.LENGTH_SHORT)
//				.show();
		Intent myin = new Intent(Bookmark.this, SampleBrowser.class);
		myin.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		myaddress.setURLFrom(site_URL[arg2]);
		myaddress.setReturnCheck(false);
		startActivity(myin);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bOK:
			Name = name.getText().toString();
			Url = url.getText().toString();
			// Toast.makeText(this, "Long Click your name : " + Name
			// +" Address : " + Url, Toast.LENGTH_SHORT).show();
			if (Name.length() == 0 || Url.length() == 0) {
				Toast.makeText(this, "Please Enter name and URL",
						Toast.LENGTH_SHORT).show();
				break;
			} else if (Name.contains(" ") || Url.contains(" ")
					|| Name.contains(",") || Url.contains(",")) {
				Toast.makeText(getApplicationContext(),
						"Please Don't use space or comma", Toast.LENGTH_SHORT)
						.show();
				break;
			}
			diditWork = true;
			try {
				String uname = Name;
				String umerit = Url;
				long lRow = current_row_id;
				Merit ex = new Merit(this);
				ex.open();
				ex.updateEntry(lRow, uname, umerit);
				ex.close();
			} catch (Exception e) {
				diditWork = false;
				String error = e.toString();
				Dialog d = new Dialog(this);
				d.setTitle("Dang it ! ");
				TextView tv = new TextView(this);
				tv.setTextColor(Color.WHITE);
				tv.setText(error);
				d.setContentView(tv);
				d.show();
			} finally {
				if (diditWork) {
					Dialog d = new Dialog(this);
					d.setTitle("Heck yea!");
					TextView tv = new TextView(this);
					tv.setTextColor(Color.WHITE);
					tv.setText("Edit Success");
					d.setContentView(tv);
					d.show();
				}
			}
			SetInfo();
			dialog.dismiss();
			break;
		case R.id.bCancel:
			dialog.dismiss();
			break;
		case R.id.bDeleteBookMark:
			diditWork = true;
			try {
				long lRow1 = current_row_id;
				Merit ex1 = new Merit(this);
				ex1.open();
				ex1.deleteEntry(lRow1);
				ex1.close();
			} catch (Exception e) {
				diditWork = false;
				String error = e.toString();
				Dialog d = new Dialog(this);
				d.setTitle("Dang it ! ");
				TextView tv = new TextView(this);
				tv.setTextColor(Color.WHITE);
				tv.setText(error);
				d.setContentView(tv);
				d.show();
			} finally {
				if (diditWork) {
					Dialog d = new Dialog(this);
					d.setTitle("Heck yea!");
					TextView tv = new TextView(this);
					tv.setTextColor(Color.WHITE);
					tv.setText("Delete Success");
					d.setContentView(tv);
					d.show();
				}
			}
			SetInfo();
			dialog.dismiss();
			break;
		case R.id.bOkAddNewBookmark:
			String myNewName = NewName.getText().toString();
			String myNewUrl = NewUrl.getText().toString();
			if (myNewName.length() == 0 || myNewUrl.length() == 0) {
				Toast.makeText(this, "Please Enter name and URL",
						Toast.LENGTH_SHORT).show();
				break;
			} else if (myNewName.contains(" ") || myNewUrl.contains(" ")
					|| myNewName.contains(",") || myNewUrl.contains(",")) {
				Toast.makeText(getApplicationContext(),
						"Please Don't use Space or comma", Toast.LENGTH_SHORT)
						.show();
				break;
			}
			diditWork = true;
			try {
				Merit entry = new Merit(Bookmark.this);
				entry.open();
				entry.createEntry(myNewName, myNewUrl);
				entry.close();
			} catch (Exception e) {
				diditWork = false;
				String error = e.toString();
				Dialog d = new Dialog(this);
				d.setTitle("Dang it ! ");
				TextView tv = new TextView(this);
				tv.setTextColor(Color.WHITE);
				tv.setText(error);
				d.setContentView(tv);
				d.show();
			} finally {
				if (diditWork) {
					Dialog d = new Dialog(this);
					d.setTitle("Heck yea!");
					TextView tv = new TextView(this);
					tv.setTextColor(Color.WHITE);
					tv.setText("Insert Success");
					d.setContentView(tv);
					d.show();
				}
			}
			SetInfo();
			addnewDialog.dismiss();
			break;
		case R.id.bCancelAddingBookmark:
			addnewDialog.dismiss();
			break;
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.bookmark_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.mAddNew:
			// Toast.makeText(this, "menu : ADD New" ,
			// Toast.LENGTH_SHORT).show();
			addnewDialog.show();
			break;
		case R.id.mExitBookmark:
			// Toast.makeText(this, "menu : Bookmark" ,
			// Toast.LENGTH_SHORT).show();
			finish();
			break;
		}
		return false;
	}
}
