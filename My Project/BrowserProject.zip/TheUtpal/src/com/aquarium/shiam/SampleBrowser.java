package com.aquarium.shiam;

import java.util.Locale;
import com.aquarium.shiam.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.ClipboardManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.InputMethodManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings.RenderPriority;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("SetJavaScriptEnabled")
public class SampleBrowser extends Activity implements OnClickListener,
		OnFocusChangeListener,TextToSpeech.OnInitListener {

	int GoID, BookmarkID, StopLoading;
	EditText webViewurl,NewName,newUrl;
	WebView ourView;
	Button bookmark, go, back, forward, reload, history, stoploading,addnewBookamrkButton,cancelBookmarkDialog;
	ProgressBar mProgressDialog;
	String Name, Url;
	public static String getURLform = "",myCurentURL;
	public static boolean returnCheck = false;
	Merit entry = new Merit(this);
	private TextToSpeech myTTS;
	Dialog addBookmark;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.samplebrowser);
		ourView = (WebView) findViewById(R.id.wvBrowser);

		ourView.getSettings().setJavaScriptEnabled(true);
		ourView.getSettings().setLoadWithOverviewMode(true);
		ourView.getSettings().setUseWideViewPort(true);
		ourView.getSettings().setSavePassword(true);
		ourView.getSettings().setSaveFormData(true);
		ourView.getSettings().setAppCacheEnabled(true);
		ourView.getSettings().setSupportZoom(true);
		ourView.getSettings().setAllowFileAccess(true);
		ourView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
		ourView.getSettings().setRenderPriority(RenderPriority.HIGH);

		ourView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// TODO Auto-generated method stub
				super.shouldOverrideUrlLoading(view, url);
				view.loadUrl(url);
				return true;
			}

			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				Toast.makeText(getApplicationContext(), description + ".",
						Toast.LENGTH_SHORT).show();
			}

			public void onPageFinished(WebView view, String url) {
				mProgressDialog.setVisibility(ProgressBar.GONE);
				go.setId(GoID);
				go.setText("Go");
				go.setBackgroundDrawable(getResources().getDrawable(
						android.R.drawable.btn_default));
				entry.open();
				if (entry.isURLInHistory(url)) {
					entry.createHistoryEntry(url);
				}
				entry.close();
				myCurentURL = url;
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				mProgressDialog = (ProgressBar) findViewById(R.id.pbPageLoading);
				mProgressDialog.setProgress(0);
				mProgressDialog.setMax(100);
				mProgressDialog.setVisibility(ProgressBar.VISIBLE);
				go.setId(StopLoading);
				go.setText("");
				go.setBackgroundDrawable(getResources().getDrawable(
						R.drawable.stopicon));
				webViewurl.setText(url);

			}
		});
		ourView.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				mProgressDialog.setProgress(progress);
			}
		});
		
		addNewBookmark();
		addnewBookamrkButton = (Button) addBookmark.findViewById(R.id.bOkAddNewBookmark);
		cancelBookmarkDialog = (Button) addBookmark.findViewById(R.id.bCancelAddingBookmark);
		NewName = (EditText) addBookmark.findViewById(R.id.etgetNewName);
		newUrl = (EditText) addBookmark.findViewById(R.id.etgetNewURL);
		go = (Button) findViewById(R.id.bGo);
		back = (Button) findViewById(R.id.bBack);
		forward = (Button) findViewById(R.id.bForward);
		reload = (Button) findViewById(R.id.bRefresh);
		history = (Button) findViewById(R.id.bHistory);
		bookmark = (Button) findViewById(R.id.bBookmark);
		stoploading = (Button) findViewById(R.id.bStopLoading);
		webViewurl = (EditText) findViewById(R.id.etURL);
		webViewurl.setMaxLines(2);

		webViewurl.setOnFocusChangeListener(this);

		go.setOnClickListener(this);
		back.setOnClickListener(this);
		forward.setOnClickListener(this);
		reload.setOnClickListener(this);
		history.setOnClickListener(this);
		bookmark.setOnClickListener(this);
		stoploading.setOnClickListener(this);
		addnewBookamrkButton.setOnClickListener(this);
		cancelBookmarkDialog.setOnClickListener(this);

		GoID = go.getId();
		BookmarkID = bookmark.getId();
		StopLoading = stoploading.getId();
	}
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bGo:
			String thesite = webViewurl.getText().toString();
			ourView.loadUrl(thesite);
			webViewurl.setText(ourView.getUrl());
			if (URLUtil.isValidUrl(thesite))
				ourView.loadUrl(thesite);
			else {
				Toast.makeText(getApplicationContext(), "Not a valid URL",
						Toast.LENGTH_SHORT).show();
				break;
			}
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(webViewurl.getWindowToken(), 0);
			break;
		case R.id.bBack:
			if (ourView.canGoBack())
				ourView.goBack();
			break;
		case R.id.bForward:
			if (ourView.canGoForward())
				ourView.goForward();
			break;
		case R.id.bRefresh:
			ourView.reload();
			break;
		case R.id.bHistory:
			ourView.clearHistory();
			break;
		case R.id.bBookmark:
			entry.open();
			if(entry.isURLInBookmark(myCurentURL)){
				showAlert();
			} else {
				addBookmark.show();
				newUrl.setText(myCurentURL);
			}
			entry.close();
			break;
		case R.id.bStopLoading:
			ourView.stopLoading();
			mProgressDialog.setVisibility(ProgressBar.GONE);
			go.setId(GoID);
			go.setText("GO");
			break;
		case R.id.bOkAddNewBookmark:
			String myNewName = NewName.getText().toString();
			String myNewUrl = newUrl.getText().toString();
			if (myNewName.length() == 0 || myNewUrl.length() == 0) {
				Toast.makeText(this, "Please Enter name and URL",
						Toast.LENGTH_SHORT).show();
				break;
			} else if (myNewName.contains(" ") || myNewUrl.contains(" ")
					|| myNewName.contains(",") || myNewUrl.contains(",")) {
				Toast.makeText(getApplicationContext(),
						"Please Don't use Space or comma", Toast.LENGTH_SHORT)
						.show();
				break;
			}
			boolean diditWork = true;
			try {
				Merit entry = new Merit(SampleBrowser.this);
				entry.open();
				entry.createEntry(myNewName, myNewUrl);
				entry.close();
			} catch (Exception e) {
				diditWork = false;
				String error = e.toString();
				Dialog d = new Dialog(this);
				d.setTitle("Dang it ! ");
				TextView tv = new TextView(this);
				tv.setTextColor(Color.WHITE);
				tv.setText(error);
				d.setContentView(tv);
				d.show();
			} finally {
				if (diditWork) {
					Dialog d = new Dialog(this);
					d.setTitle("Heck yea!");
					TextView tv = new TextView(this);
					tv.setTextColor(Color.WHITE);
					tv.setText("Insert Success");
					d.setContentView(tv);
					d.show();
				}
			}
			go.setBackgroundDrawable(getResources().getDrawable(R.drawable.yellowstar));
			addBookmark.dismiss();
			break;
		case R.id.bCancelAddingBookmark:
			addBookmark.dismiss();
			break;
		}		
	}
	public void addNewBookmark(){
		addBookmark = new Dialog(SampleBrowser.this);
		addBookmark.setContentView(R.layout.mydialog_add_item);
		addBookmark.setTitle("Enter Bookmark");
		addBookmark.setCancelable(true);
		addBookmark.getWindow().setLayout(400, 500);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater blowup = getMenuInflater();
		blowup.inflate(R.menu.activity_main, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.mAbotus:
			Intent aboutIntent = new Intent("com.aquarium.shiam.ABOUT");
			startActivity(aboutIntent);
			break;
		case R.id.mPreference:
			LinearLayout buttonslayout = (LinearLayout) findViewById(R.id.lButtonslayout);
			LinearLayout editTextLayout = (LinearLayout) findViewById(R.id.lEditTextLayout);
			if(buttonslayout.getVisibility() == View.VISIBLE){
				buttonslayout.setVisibility(View.GONE);
				editTextLayout.setVisibility(View.GONE);
			} else {
				buttonslayout.setVisibility(View.VISIBLE);
				editTextLayout.setVisibility(View.VISIBLE);				
			}
			break;
		case R.id.mBookmark:
			Intent bookmarkIntent = new Intent(this, Bookmark.class);
			startActivity(bookmarkIntent);
			break;
		case R.id.mHistory:
			Intent history = new Intent(this, History.class);
			startActivity(history);
			break;
		case R.id.mExit:
			finish();
			break;
		case R.id.mNarrate:	
			speakOut();
			return true;

		case R.id.mSeelctandCopy:
			selectAndCopyText();
			return true;

		case R.id.mSoundSpeed:
			return true;
		case R.id.submenu1:
			if (item.isChecked())
				item.setChecked(false);
			else {
				item.setChecked(true);
				myTTS.setSpeechRate((float) 0.6);
			}
			return true;
		case R.id.submenu2:
			if (item.isChecked())
				item.setChecked(false);
			else {
				item.setChecked(true);
				myTTS.setSpeechRate((float) 1.0);
			}
			return true;
		case R.id.submenu3:
			if (item.isChecked())
				item.setChecked(false);
			else {
				item.setChecked(true);
				myTTS.setSpeechRate((float) 2.0);
			}
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
		return false;
	}
	@Override
	public void onFocusChange(View v, boolean hasFocus) {
		if (hasFocus) {
			go.setId(GoID);
			go.setText("Go");
			go.setBackgroundDrawable(getResources().getDrawable(
					android.R.drawable.btn_default));
		} else {
			go.setId(BookmarkID);
			go.setBackgroundDrawable(getResources().getDrawable(
					R.drawable.starsilver));
			entry.open();
			if(entry.isURLInBookmark(myCurentURL)){
				go.setBackgroundDrawable(getResources().getDrawable(R.drawable.yellowstar));
			} else {
				go.setBackgroundDrawable(getResources().getDrawable(R.drawable.starsilver));
			}
			entry.close();
			go.setText("");
		}
	}
	public void setURLFrom(String str) {
		getURLform = str;
	}
	public void setReturnCheck(boolean data) {
		returnCheck = data;
	}
	public void selectAndCopyText() {
		try {
			KeyEvent shiftPressEvent = new KeyEvent(0, 0, KeyEvent.ACTION_DOWN,
					KeyEvent.KEYCODE_SHIFT_LEFT, 0, 0);
			shiftPressEvent.dispatch(ourView);
		} catch (Exception e) {
			throw new AssertionError(e);
		}
	}
	public void speakOut(){
		ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
		String text = clipboard.getText().toString();
		myTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
		Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		myTTS = new TextToSpeech(SampleBrowser.this,this);
		if (returnCheck)
			return;
		try {
			String getURL = getURLform;
			if (getURL == "") {
				// getURL = "1";
				getURL = "http://www.kuet.ac.bd/";//"https://www.yahoo.com/";
				webViewurl.setText(getURL);
				if (URLUtil.isValidUrl(getURL))
					ourView.loadUrl(getURL);
				else
					Toast.makeText(getApplicationContext(), "Not a valid URL",
							Toast.LENGTH_SHORT).show();
			} else {
				if (URLUtil.isValidUrl(getURL))
					ourView.loadUrl(getURL);
				else {
					Toast.makeText(getApplicationContext(), "Not a valid URL",
							Toast.LENGTH_SHORT).show();
					return;
				}
			}

		} catch (Exception e) {
			Log.e("isURLInHistory", e.toString());
		} finally {
		}
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		if(myTTS !=null){
			myTTS.stop();
			myTTS.shutdown();
		}
		super.onPause();
	}
	@Override
	public void onInit(int status) {
		// TODO Auto-generated method stub
		if (status == TextToSpeech.SUCCESS) {
            int result = myTTS.setLanguage(Locale.US);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "This Language is not supported");
            } else {
            	Log.e("TTS", "All Right Go on");
            }
 
        } else {
            Log.e("TTS", "Initilization Failed!");
        }
	}
	public void showAlert(){
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(SampleBrowser.this);
        alertDialog.setTitle("Confirm Delete...");
        alertDialog.setMessage("Are you sure you want remove this Bookmark?");
		
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
            	boolean diditWork = true;
    			try {    				
    				entry.open();
    				entry.DeleteBookmark(myCurentURL);
    				entry.close();
    			} catch (Exception e) {
    				diditWork = false;
    				String error = e.toString();
    				Dialog d = new Dialog(SampleBrowser.this);
    				d.setTitle("Dang it ! ");
    				TextView tv = new TextView(SampleBrowser.this);
    				tv.setTextColor(Color.WHITE);
    				tv.setText(error);
    				d.setContentView(tv);
    				d.show();
    			} finally {
    				if (diditWork) {
    					Dialog d = new Dialog(SampleBrowser.this);
    					d.setTitle("Heck yea!");
    					TextView tv = new TextView(SampleBrowser.this);
    					tv.setTextColor(Color.WHITE);
    					tv.setText("Delete Success");
    					d.setContentView(tv);
    					d.show();
    				}
    			}
    			go.setBackgroundDrawable(getResources().getDrawable(R.drawable.starsilver));
            }
        });
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            }
        });
        alertDialog.show();
	}
}
