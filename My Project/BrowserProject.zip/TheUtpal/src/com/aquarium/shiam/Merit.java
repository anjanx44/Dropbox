package com.aquarium.shiam;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Merit {
	public static final String KEY_ROWID = "_id";
	public static final String KEY_NAME = "site_name";
	public static final String KEY_URL = "site_url";

	private static final String DATABASE_NAME = "Meritdb";
	private static final String DATABASE_TABLE = "peopleTable";
	private static final String DATABASE_HISTORY_TABLE = "historyTable";
	private static final int DATABASE_VERSION = 1;

	private DBHelper ourhelper;
	private final Context ourcontext;
	private SQLiteDatabase ourDatabse;

	int[] site_row_id;

	private class DBHelper extends SQLiteOpenHelper {

		public DBHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + DATABASE_TABLE + "(" + KEY_ROWID
					+ " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_NAME
					+ " TEXT NOT NULL, " + KEY_URL + " TEXT NOT NULL );");

			db.execSQL("CREATE TABLE " + DATABASE_HISTORY_TABLE + "("
					+ KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
					+ KEY_URL + " TEXT NOT NULL );");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS" + DATABASE_TABLE);
			db.execSQL("DROP TABLE IF EXISTS" + DATABASE_HISTORY_TABLE);
			onCreate(db);
		}
	}
	public Merit(Context c) {
		ourcontext = c;
	}
	public Merit open() throws SQLException {
		ourhelper = new DBHelper(ourcontext);
		ourDatabse = ourhelper.getWritableDatabase();
		return this;
	}
	public void close() {
		ourhelper.close();
	}
	public long createEntry(String name, String merit) {
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(KEY_NAME, name);
		cv.put(KEY_URL, merit);
		return ourDatabse.insert(DATABASE_TABLE, null, cv);
	}
	public long createHistoryEntry(String merit) {
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(KEY_URL, merit);
		return ourDatabse.insert(DATABASE_HISTORY_TABLE, null, cv);
	}
	public String getData() {
		// TODO Auto-generated method stub
		String[] column = new String[] { KEY_ROWID, KEY_NAME, KEY_URL };
		Cursor c = ourDatabse.query(DATABASE_TABLE, column, null, null, null,
				null, null);
		String results = new String(), site_url = new String(), row_ID = new String();
		int iROW = c.getColumnIndex(KEY_ROWID);
		int iNAME = c.getColumnIndex(KEY_NAME);
		int iMERIT = c.getColumnIndex(KEY_URL);
		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
			row_ID += c.getString(iROW) + " ";
			results += c.getString(iNAME) + " ";
			site_url += c.getString(iMERIT) + " ";
		}
		c.close();
		return results + "," + site_url + "," + row_ID;
	}
	public String getHistoryData() {
		// TODO Auto-generated method stub
		String[] column = new String[] { KEY_ROWID, KEY_URL };
		Cursor c = ourDatabse.query(DATABASE_HISTORY_TABLE, column, null, null,
				null, null, null);
		String site_url = new String(), row_ID = new String();
		int iROW = c.getColumnIndex(KEY_ROWID);
		int iMERIT = c.getColumnIndex(KEY_URL);
		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
			row_ID += c.getString(iROW) + " ";
			site_url += c.getString(iMERIT) + " ";
		}
		c.close();
		return site_url + "," + row_ID;
	}
	public String getname(long l) throws SQLException {
		// TODO Auto-generated method stub
		String[] column = new String[] { KEY_ROWID, KEY_NAME, KEY_URL };
		Cursor c = ourDatabse.query(DATABASE_TABLE, column,
				KEY_ROWID + "=" + l, null, null, null, null);
		if (c != null) {
			c.moveToFirst();
			String name = c.getString(1);
			return name;
		}
		return null;
	}
	public String getmerit(long l) throws SQLException {
		// TODO Auto-generated method stub
		String[] column = new String[] { KEY_ROWID, KEY_NAME, KEY_URL };
		Cursor c = ourDatabse.query(DATABASE_TABLE, column,
				KEY_ROWID + "=" + l, null, null, null, null);
		if (c != null) {
			c.moveToFirst();
			String merit = c.getString(2);
			return merit;
		}
		return null;
	}
	public void updateEntry(long lRow, String uname, String umerit)
			throws SQLException {
		// TODO Auto-generated method stub
		ContentValues cvUpdate = new ContentValues();
		cvUpdate.put(KEY_NAME, uname);
		cvUpdate.put(KEY_URL, umerit);
		ourDatabse.update(DATABASE_TABLE, cvUpdate, KEY_ROWID + "=" + lRow,
				null);
	}
	public void deleteEntry(long lRow1) throws SQLException {
		// TODO Auto-generated method stub
		ourDatabse.delete(DATABASE_TABLE, KEY_ROWID + "=" + lRow1, null);
	}
	public void deleteHistoryEntry(long lRow1) throws SQLException {
		// TODO Auto-generated method stub
		ourDatabse.delete(DATABASE_HISTORY_TABLE, KEY_ROWID + "=" + lRow1, null);
	}
	public boolean isURLInHistory(String str) {
		// TODO Auto-generated method stub
		String query = "SELECT " + "*" + " FROM "
				+ DATABASE_HISTORY_TABLE ;
		Cursor c = ourDatabse.rawQuery(query, null);
		//Toast.makeText(ourcontext, c.toString(),Toast.LENGTH_SHORT).show();
		if (c.getCount() > 0) 
		{               
		    c.moveToFirst();
		    do {
		           if( str.equals( c.getString(c.getColumnIndex(KEY_URL))) ){
		        	   c.close();
		        	   return false;
		           }
		           
		    } while (c.moveToNext());
		}
		c.close();
		return true;
	}
	public boolean isURLInBookmark(String str){
		String query = "SELECT " + "*" + " FROM "
				+ DATABASE_TABLE ;
		Cursor c = ourDatabse.rawQuery(query, null);
		//Toast.makeText(ourcontext, c.toString(),Toast.LENGTH_SHORT).show();
		if (c.getCount() > 0) 
		{               
		    c.moveToFirst();
		    do {
		           if( str.equals( c.getString(c.getColumnIndex(KEY_URL))) ){
		        	   c.close();
		        	   return true;
		           }
		           
		    } while (c.moveToNext());
		}
		c.close();
		return false;
	}
	public void DeleteBookmark(String str){
		String query = "SELECT " + "*" + " FROM "
				+ DATABASE_TABLE ;
		Cursor c = ourDatabse.rawQuery(query, null);
		if (c.getCount() > 0) 
		{               
		    c.moveToFirst();
		    do {
		           if( str.equals( c.getString(c.getColumnIndex(KEY_URL))) ){
		        	   String row_ID = c.getString(c.getColumnIndex(KEY_ROWID));
		        	   ourDatabse.delete(DATABASE_TABLE, KEY_ROWID + "=" + row_ID, null);
		        	   c.close();
		        	   return;
		           }
		           
		    } while (c.moveToNext());
		}
	}
	public void DeleteAllHistory(){
		ourDatabse.delete(DATABASE_HISTORY_TABLE,null, null);
	}
}
